---
name: Nocturne Kinetic
colors:
  surface: '#11131c'
  surface-dim: '#11131c'
  surface-bright: '#373943'
  surface-container-lowest: '#0c0e17'
  surface-container-low: '#191b24'
  surface-container: '#1d1f29'
  surface-container-high: '#282933'
  surface-container-highest: '#32343e'
  on-surface: '#e1e1ef'
  on-surface-variant: '#c7c4d7'
  inverse-surface: '#e1e1ef'
  inverse-on-surface: '#2e303a'
  outline: '#908fa0'
  outline-variant: '#464554'
  surface-tint: '#c0c1ff'
  primary: '#c0c1ff'
  on-primary: '#1000a9'
  primary-container: '#8083ff'
  on-primary-container: '#0d0096'
  inverse-primary: '#494bd6'
  secondary: '#ffb95f'
  on-secondary: '#472a00'
  secondary-container: '#ee9800'
  on-secondary-container: '#5b3800'
  tertiary: '#bdc2ff'
  on-tertiary: '#131e8c'
  tertiary-container: '#7c87f3'
  on-tertiary-container: '#081486'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e1e0ff'
  primary-fixed-dim: '#c0c1ff'
  on-primary-fixed: '#07006c'
  on-primary-fixed-variant: '#2f2ebe'
  secondary-fixed: '#ffddb8'
  secondary-fixed-dim: '#ffb95f'
  on-secondary-fixed: '#2a1700'
  on-secondary-fixed-variant: '#653e00'
  tertiary-fixed: '#e0e0ff'
  tertiary-fixed-dim: '#bdc2ff'
  on-tertiary-fixed: '#000767'
  on-tertiary-fixed-variant: '#2f3aa3'
  background: '#11131c'
  on-background: '#e1e1ef'
  surface-variant: '#32343e'
typography:
  display-hero:
    fontFamily: Outfit
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Outfit
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Outfit
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.025em
  headline-lg-mobile:
    fontFamily: Outfit
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Outfit
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Outfit
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Manrope
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-sm:
    fontFamily: Manrope
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.005em
  label-lg:
    fontFamily: Outfit
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Outfit
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Outfit
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.06em
  metric-price:
    fontFamily: Outfit
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.02em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xxs: 0.125rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
  space-xxl: 4rem
---

## Brand & Style

The visual narrative bridges architectural night culture with high-precision transaction design. Built for cultural seekers, live-music curators, and premium event-goers, the interface establishes an immersive, nocturnal salon atmosphere while maintaining the sharp, friction-free clarity of an elite financial checkout. 

The aesthetic is anchored in an elevated, dark-mode architectural minimalism infused with kinetic micro-accents. Interfaces avoid generic festival neon clutter in favor of deep obsidian canvas layers, razor-sharp structural alignments, and targeted strikes of electric violet and warm champagne amber. Every screen evokes anticipation, intimacy, and curation, treating live performance and venue discovery as high-art cultural investments.

## Colors

The palette leverages a deep indigo-slate continuum to generate physical atmospheric depth without reverting to pure desaturated black. 

- **Primary (`#6366F1`)**: Electric Indigo drives focal points, primary interactive states, seat selection confirmations, and checkout CTAs. It radiates energetic clarity without producing visual fatigue against dark planes.
- **Secondary (`#F59E0B`)**: Radiant Amber functions selectively for live status flags, limited ticket inventory warnings, VIP tiers, and real-time temporal alerts (e.g., "Doors Closing", "Selling Fast").
- **Tertiary (`#818CF8`)**: Soft Ultraviolet provides supportive chromatic resonance for interactive hover halos, secondary metadata highlights, and venue map vectors.
- **Neutral (`#0F111A`)**: Deep Obsidian forms the foundational substrate. Secondary nested containers utilize calibrated step-ups (`#161926`, `#1E2235`, and `#282D44`) to construct hierarchy through luminance layering rather than harsh chromatic contrast.
- **Text & Foreground**: Primary body sits at `#F8FAFC` (96% luminance), secondary descriptors at `#94A3B8`, and structural divider strokes at `#1E2338` (12–16% alpha overlays).

## Typography

Typography establishes an intentional tension between the geometric, confident display weights of Outfit and the technical, hyper-legible neutral cadence of Manrope.

- **Headlines (Outfit)**: Scaled with tight tracking and calibrated proportional figures. Headings demand visual authority across artist lineups, festival stages, and city headings.
- **Body & Data (Manrope)**: Selected for its open aperture and vertical alignment regularity, ensuring that high-density booking details, venue addresses, and payment schedules maintain effortless legibility at rapid scan speeds.
- **Labels & Tags (Outfit)**: Capitalized and upper-tracked tags deploy tight micro-proportions to balance badges, stage designations, and ticket timestamps against high-contrast backgrounds.

## Layout & Spacing

The spatial model enforces an architectural 12-column grid system built on an 8pt base metric. Spacing orchestrates content rhythm from dense administrative seating charts down to expansive editorial event canvases.

- **Desktop (>= 1280px)**: 12 columns, `margin` of `3rem`, `gutter` of `1.5rem`. Maximum content constraint of `1440px`.
- **Tablet (768px - 1279px)**: 8 columns, `margin` of `2rem`, `gutter` of `1.25rem`. Two-column card reflow for event browse matrices.
- **Mobile (< 768px)**: 4 columns, `margin-mobile` of `1.25rem`, `gutter-mobile` of `1rem`. Structural rows stack vertically, horizontal scroll decks take over ticket class discovery, and checkout steps pin actions to a fixed viewport bottom sheet.

## Elevation & Depth

Depth is established via disciplined luminance layering and calibrated ambient violet backdrops rather than muddy drop shadows. 

- **Surface Level 0 (Base Canvas)**: Hex `#0F111A`. Absorbs all ambient bleed; represents the ground plane.
- **Surface Level 1 (Listing Cards & Structural Panes)**: Hex `#161926` with a hairline stroke: `1px solid rgba(255, 255, 255, 0.06)`.
- **Surface Level 2 (Floating Popovers, Ticket Modals, Sticky Nav)**: Hex `#1E2235` backed by `backdrop-filter: blur(16px)` and an ambient, wide-diffusion shadow: `0 16px 40px -10px rgba(0, 0, 0, 0.65), 0 0 20px 0 rgba(99, 102, 241, 0.08)`.
- **Surface Level 3 (Focus States & Seating Pods)**: Targeted micro-glows using `0 0 0 1px #6366F1, 0 8px 24px -4px rgba(99, 102, 241, 0.35)`. Ambient light always carries an intentional indigo-violet tint to emulate stage illumination cutting through night atmosphere.

## Shapes

The design system maintains a tailored, micro-radius visual signature (Level 1 - Soft). By anchoring UI components to `0.25rem` (4px), containers, input fields, and dynamic chips preserve crisp architectural lines that signal precision, curation, and institutional reliability. 

- **Base Radius (`0.25rem` / 4px)**: Buttons, inputs, chips, ticket stubs, and badge tags.
- **Mid Radius (`0.5rem` / 8px)**: Event cards, modal windows, interactive seating pods, and venue diagrams.
- **Large Radius (`0.75rem` / 12px)**: Outer boundary overlays, hero banners, and expansive bottom-sheet wrappers.
- **Pill Exception**: Pure pill forms (`rounded-full`) are strictly reserved for live status indicators (e.g., pulsing "Live Now" or "Almost Gone" pips) to immediately contrast with rectangular UI architecture.

## Components

### Buttons
- **Primary Action**: Deep electric indigo background (`#6366F1`), crisp white text (`Outfit`, 600 weight), 4px border radius. Padding: `12px 24px`. Hover state: transforms to `#4F46E5` with an ambient glow (`box-shadow: 0 4px 16px rgba(99, 102, 241, 0.3)`). Active state compresses by `scale(0.98)`.
- **Secondary / Ghost**: Transparent fill, 1px perimeter border (`rgba(255, 255, 255, 0.12)`), text `#F8FAFC`. Hover applies `background: rgba(99, 102, 241, 0.08)` and border `#6366F1`.
- **VIP / Urgent CTA**: Radiant Amber gradient fill (`linear-gradient(135deg, #F59E0B 0%, #D97706 100%)`) with obsidian text (`#0F111A`, 700 weight).

### Cards (Events & Experiences)
- Structurally composed with a 16:9 or 4:5 image header framed by a subtle internal shadow overlay. Card body sits on Level 1 slate (`#161926`) surrounded by a 1px border (`rgba(255, 255, 255, 0.06)`).
- Metadata layout prioritizes date stamp and venue badges on the upper margin, followed by bold headline titles, and terminates in an anchored bottom row housing live pricing (`metric-price`) and dynamic availability indicators.

### Chips & Badges
- **Category Chips**: Micro-radius (4px), height 28px, padding `0 10px`. Background `#1E2235`, border `1px solid rgba(255, 255, 255, 0.08)`, text `#94A3B8`. Active selection switches background to `#6366F1` with crisp `#FFFFFF` typography.
- **Status & Urgency Badges**: 20px height, uppercase tracking (`label-sm`). Amber variant uses `rgba(245, 158, 11, 0.12)` background, `rgba(245, 158, 11, 0.3)` border, and `#F59E0B` text. Features a 6px circular dot indicator.

### Input Fields & Search
- Low-profile forms with 44px standard height, `#161926` background, inset text in Manrope 15px. Inactive border: `1px solid rgba(255, 255, 255, 0.1)`. 
- Focus state instantly triggers a dual perimeter definition: `1px solid #6366F1` and a tight outer halo `0 0 0 3px rgba(99, 102, 241, 0.2)`. Placeholders rendered in muted `#64748B`.

### Checkboxes & Radio Controls
- Dimensions: 18x18px, 3px radius for checkboxes, full circle for radios. Border is `1.5px solid rgba(255, 255, 255, 0.2)`. Checked state fills `#6366F1` with an optical white check icon and subtle neon bloom.

### Ticket Tier Selectors
- Modular segmented tiers featuring ticket name, access perks, inventory counters, and real-time total calculation. Active selection reveals an indigo accent border on the left perimeter (3px width) and lifts container elevation to Level 2.